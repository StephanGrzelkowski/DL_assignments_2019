import torch 

x = torch.ones(5, 3, 4)
b = torch.ones(5,3)

#print(b[:,1,:])
print(x[:,1])
