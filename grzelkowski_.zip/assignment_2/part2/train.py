# MIT License
#
# Copyright (c) 2019 Tom Runia
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to conditions.
#
# Author: Deep Learning Course | Fall 2019
# Date Created: 2019-09-06
################################################################################

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import time
from datetime import datetime
import argparse

import numpy as np

import torch
import torch.optim as optim
from torch.utils.data import DataLoader

import sys
sys.path.append("..")

from part2.dataset import TextDataset
from part2.model import TextGenerationModel

import utils
import random
################################################################################

def train(config):

    # Initialize the device which to run the model on
    device = torch.device(config.device)

    #get data file directory
    data_dir = "assets/"
    file_path = data_dir + config.txt_file
   
    # Initialize the dataset and data loader (note the +1)
    dataset = TextDataset( file_path, config.seq_length)  # fixme
    data_loader = DataLoader(dataset, config.batch_size, num_workers=1)
    vocabulary_size = dataset.vocab_size

     # Initialize the model that we are going to use
    model = TextGenerationModel(config.batch_size, 
    config.seq_length, 
    vocabulary_size,
    config.lstm_num_hidden, 
    config.lstm_num_layers, 
    config.device)  

    # Setup the loss and optimizer
    criterion = torch.nn.CrossEntropyLoss()  # fixme
    optimizer = optim.RMSprop(model.parameters(), lr=config.learning_rate)  # fixme
    
    accuracy_list = []
    accuracy_list_test = []
    loss_list = []
    loss_list_test = []
    epochs = []
    for step, (batch_inputs, batch_targets) in enumerate(data_loader):
        
        # Only for time measurement of step through network
        t1 = time.time()

        #######################################################
        # Add more code here ...
        #######################################################
        
        #transform to one-hot and put on device
        batch_inputs = torch.nn.functional.one_hot(batch_inputs.to(torch.int64), vocabulary_size)
        batch_inputs = batch_inputs.to(torch.float).to(device)

        batch_targets = batch_targets.to(device).to(torch.int64)
        
        optimizer.zero_grad()

        out = model(batch_inputs)

        out = out.reshape(-1, vocabulary_size)

        batch_targets = batch_targets.reshape(-1)

        loss = criterion(out, batch_targets)   # fixme

        loss.backward()
        torch.nn.utils.clip_grad_norm(model.parameters(), max_norm=config.max_norm)
        optimizer.step()
        

        accuracy = utils.calc_accuracy(out, batch_targets) # fixme
        
        # Just for time measurement
        t2 = time.time()
        examples_per_second = config.batch_size/float(t2-t1)

        if (step % config.print_every) == 0:

            print("[{}] Train Step {:04d}/{:04f}, Batch Size = {}, Examples/Sec = {:.2f}, "
                  "Accuracy = {:.2f}, Loss = {:.3f}".format(
                    datetime.now().strftime("%Y-%m-%d %H:%M"), step,
                    config.train_steps, config.batch_size, examples_per_second,
                    accuracy, loss))
            accuracy_list.append(accuracy)
            loss_list.append(loss)
            epochs.append(step)

        if (step % config.sample_every) == 0:
            # Generate some sentences by sampling from the model
            #start with random one-hot integer
            start_character = random.randint(0, vocabulary_size -1)
            in_sample = torch.zeros((1, 1, vocabulary_size), device=config.device)
            in_sample[0,0,start_character] = 1
            sample = model.sample(in_sample, config.sample_length - 1, config.sample_random, config.temperature)
            sample = sample.squeeze()
            print(sample.size())
            _, res = sample.max(1)
            print(res)
            string_sample = dataset.convert_to_string(res.cpu().numpy())
            print("sample:{}".format(string_sample))

        if step == config.train_steps:
            # If you receive a PyTorch data-loader error, check this bug report:
            # https://github.com/pytorch/pytorch/pull/9655
            str_save = 'text_generation'
            name_run = input('what shall we call this run?')
            str_save += name_run
            print(str_save)

            save_dir = '../../../saveData/assignment2_part2'
            utils.save_results(loss_list, accuracy_list,  None, epochs, str_save=str_save, save_dir=save_dir, FLAGS = None)
            utils.plot_accuracies(loss_list, accuracy_list, None, epochs, str_save=str_save, save_dir=save_dir, FLAGS = str_save)

            break
    print('Done training.')


 ################################################################################
 ################################################################################

if __name__ == "__main__":

    # Parse training configuration
    parser = argparse.ArgumentParser()

    # Model params
    parser.add_argument('--txt_file', type=str, required=True, help="Path to a .txt file to train on")
    parser.add_argument('--seq_length', type=int, default=30, help='Length of an input sequence')
    parser.add_argument('--lstm_num_hidden', type=int, default=128, help='Number of hidden units in the LSTM')
    parser.add_argument('--lstm_num_layers', type=int, default=2, help='Number of LSTM layers in the model')

    # Training params
    parser.add_argument('--batch_size', type=int, default=64, help='Number of examples to process in a batch')
    parser.add_argument('--learning_rate', type=float, default=2e-3, help='Learning rate')

    # It is not necessary to implement the following three params, but it may help training.
    parser.add_argument('--learning_rate_decay', type=float, default=0.96, help='Learning rate decay fraction')
    parser.add_argument('--learning_rate_step', type=int, default=5000, help='Learning rate step')
    parser.add_argument('--dropout_keep_prob', type=float, default=1.0, help='Dropout keep probability')

    parser.add_argument('--train_steps', type=int, default=1e6, help='Number of training steps')
    parser.add_argument('--max_norm', type=float, default=5.0, help='--')

    # Misc params
    parser.add_argument('--summary_path', type=str, default="./summaries/", help='Output path for summaries')
    parser.add_argument('--print_every', type=int, default=5, help='How often to print training progress')
    parser.add_argument('--sample_every', type=int, default=100, help='How often to sample from the model')

    parser.add_argument('--device', type=str, default="cuda:0", help='Gpu device for PyTorch')
    parser.add_argument('--sample_length', type=int, default=30, help='Target sample length')
    parser.add_argument('--sample_random', type=int, default=0, help='Random sampling')
    parser.add_argument('--temperature', type=int, default=1, help='temperature parameter')


    config = parser.parse_args()

    # Train the model
    train(config)
